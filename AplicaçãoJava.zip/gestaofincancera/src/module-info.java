/**
 * 
 */
/**
 * @author monitor
 *
 */
module gestaofincancera {
	requires java.desktop;
}