package gestaofinanceira;

public class Registro {
	/**
	 * Declaração dos parâmetros do objeto Registro
	 */
    private double valor;
    private String tipo;
    private String nomeRegistro;

    /**
     * Método construtor do objeto
     * @param nomeRegistro O nome que será o motivo do ativo, ou passivo
     * @param valor O número dado para aumentar ou diminuir o saldo
     * @param tipo Ativo se refere a entrada de dinheiro e Passivo a saida
     */
    public Registro(String nomeRegistro,double valor,String tipo) {
        this.valor = valor;
        this.tipo = tipo;
        this.nomeRegistro = nomeRegistro;
    }

    //Métodos Getters and Setters//
    public double getValor() {
        return valor;
    }

    public String getTipo() {
        return tipo;
    }

    public String getNomeRegistro() {
        return nomeRegistro;
    }

    //Método to String, para mostrar na lista os dados do registro//
    @Override
    public String toString() {
        return "Nome: " + nomeRegistro + ", Valor: " + valor + ", Tipo: " + tipo;
    }
}
