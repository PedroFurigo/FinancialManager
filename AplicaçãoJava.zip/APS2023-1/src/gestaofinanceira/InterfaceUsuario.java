/**
 * O pacote "gestaofincancera" contém a classe "InterfaceUsuario" que representa a interface
 * de entrada do usuário para iniciar a aplicação de gestão financeira.
 */
package gestaofinanceira;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterfaceUsuario {
    private JFrame frame;
    private JTextField nomeField;
    private JTextField salarioField;

    /**
     * Método principal que inicia a aplicação.
     *
     * @param args os argumentos de linha de comando
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                InterfaceUsuario interfaceUsuario = new InterfaceUsuario();
                interfaceUsuario.initialize();
                interfaceUsuario.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Inicializa a interface do usuário.
     */
    public void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel nomeLabel = new JLabel("Nome:");
        nomeLabel.setBounds(10, 10, 70, 20);
        frame.getContentPane().add(nomeLabel);

        nomeField = new JTextField();
        nomeField.setBounds(90, 10, 180, 20);
        frame.getContentPane().add(nomeField);

        JLabel salarioLabel = new JLabel("Salário:");
        salarioLabel.setBounds(10, 40, 70, 20);
        frame.getContentPane().add(salarioLabel);

        salarioField = new JTextField();
        salarioField.setBounds(90, 40, 180, 20);
        frame.getContentPane().add(salarioField);

        JButton continuarButton = new JButton("Continuar");
        continuarButton.setBounds(90, 80, 100, 25);
        continuarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nome = nomeField.getText();
                double salario = Double.parseDouble(salarioField.getText());

                frame.dispose(); // Fechar a janela atual

                /**
                 *  Criar um novo usuário com nome e salário
                 */
                Usuario usuario = new Usuario(nome, salario);
                usuario.setSaldo(salario);

                // Abrir a interface principal passando o usuário
                Interface app = new Interface(usuario);
                app.initialize();
                app.getFrame().setVisible(true);
            }
        });
        frame.getContentPane().add(continuarButton);
    }
}
