package gestaofinanceira;

import javax.swing.*;
import javax.swing.text.JTextComponent;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe responsável por criar a interface gráfica da aplicação de gestão financeira.
 */
public class Interface {

    private Usuario usuario;
    private List<Registro> registros = new ArrayList<>();

    // Componentes da interface
    private JFrame frame;
    private JTextField valorField;
    private JComboBox<String> tipoComboBox;
    private JTextArea listaRegistros;
    private JLabel saldoLabel;
    private JLabel nomeLabel;
    private JTextComponent nomeAtivoField;

    /**
     * Construtor da classe Interface.
     *
     * @param usuario O usuário para o qual a interface é criada.
     */
    public Interface(Usuario usuario) {
        this.usuario = usuario;
    }

    /**
     * Método responsável por inicializar a interface gráfica.
     */
    public void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 330, 500, 350); // Define o tamanho da interface
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        // Criação dos componentes da interface

        // Label e campo de texto para o nome do registro
        JLabel nomeAtivoLabel = new JLabel("Nome Registro: ");
        nomeAtivoLabel.setBounds(10, 10, 100, 20);
        frame.getContentPane().add(nomeAtivoLabel);

        nomeAtivoField = new JTextField();
        nomeAtivoField.setBounds(120, 10, 100, 20);
        frame.getContentPane().add(nomeAtivoField);

        // Label e campo de texto para o valor do registro
        JLabel valorLabel = new JLabel("Valor:");
        valorLabel.setBounds(10, 40, 70, 20);
        frame.getContentPane().add(valorLabel);

        valorField = new JTextField();
        valorField.setBounds(120, 40, 100, 20);
        frame.getContentPane().add(valorField);

        // Label e combo box para o tipo do registro
        JLabel tipoLabel = new JLabel("Tipo:");
        tipoLabel.setBounds(10, 70, 70, 20);
        frame.getContentPane().add(tipoLabel);

        tipoComboBox = new JComboBox<>();
        tipoComboBox.addItem("Ativo");
        tipoComboBox.addItem("Passivo");
        tipoComboBox.setBounds(120, 70, 100, 20);
        frame.getContentPane().add(tipoComboBox);

        // Botões de adicionar e remover registro
        JButton adicionarButton = new JButton("Adicionar");
        adicionarButton.setBounds(10, 100, 100, 25);
        adicionarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                adicionarRegistro();
            }
        });
        frame.getContentPane().add(adicionarButton);

        JButton removerButton = new JButton("Remover");
        removerButton.setBounds(120, 100, 100, 25);
        removerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                removerRegistro();
            }
        });
        frame.getContentPane().add(removerButton);

        // Label e área de texto para exibir os registros
        JLabel registrosLabel = new JLabel("Registros:");
        registrosLabel.setBounds(10, 130, 70, 20);
        frame.getContentPane().add(registrosLabel);

        listaRegistros = new JTextArea();
        listaRegistros.setBounds(10, 160, 300, 120);
        listaRegistros.setEditable(false);
        frame.getContentPane().add(listaRegistros);

        // Labels para exibir o saldo total e o nome do usuário
        JLabel saldoTextLabel = new JLabel("Saldo Total:");
        saldoTextLabel.setBounds(320, 10, 100, 20);
        frame.getContentPane().add(saldoTextLabel);

        saldoLabel = new JLabel(String.format("%.2f", usuario.getSaldo()));
        saldoLabel.setBounds(320, 30, 100, 20);
        frame.getContentPane().add(saldoLabel);

        nomeLabel = new JLabel("Nome: " + usuario.getNome());
        nomeLabel.setBounds(320, 60, 100, 20);
        frame.getContentPane().add(nomeLabel);

        // Botão para calcular o saldo e exibir o pop-up com informações
        JButton calcularButton = new JButton("Calcular Saldo");
        calcularButton.setBounds(330, 100, 120, 25);
        calcularButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcularSaldo();
                JOptionPane.showMessageDialog(frame, "Nome do usuário: " + usuario.getNome() + "\nGastos totais: " + saldoLabel.getText());
            }
        });
        frame.getContentPane().add(calcularButton);

        frame.setVisible(true);
    }

    /**
     * Método responsável por adicionar um novo registro.
     */
    private void adicionarRegistro() {
        String nomeAtivo = nomeAtivoField.getText();
        String valorStr = valorField.getText();
        if (!valorStr.isEmpty()) {
            double valor = Double.parseDouble(valorStr);
            String tipo = (String) tipoComboBox.getSelectedItem();
            Registro registro = new Registro(nomeAtivo, valor, tipo);
            registros.add(registro);
            listaRegistros.append(registro.toString() + "\n");
            valorField.setText("");
            calcularSaldo();
        } else {
            JOptionPane.showMessageDialog(frame, "Informe um valor válido.");
        }
    }

    /**
     * Método responsável por remover o último registro adicionado.
     */
    private void removerRegistro() {
        if (!registros.isEmpty()) {
        	registros.remove(registros.size() - 1);
            listaRegistros.setText("");
            for (Registro reg : registros) {
                listaRegistros.append(reg.toString() + "\n");
            }
            calcularSaldo();
        } else {
            JOptionPane.showMessageDialog(frame, "Não há registros para remover.");
        }
    }

    /**
     * Método responsável por calcular o saldo total.
     */
    private void calcularSaldo() {
        double saldo = usuario.getSaldo();
        for (Registro registro : registros) {
            if (registro.getTipo().equals("Ativo")) {
                saldo += registro.getValor();
            } else {
                saldo -= registro.getValor();
            }
        }
        saldoLabel.setText(String.format("%.2f", saldo));
    }

    /**
     * Método getter para obter o frame da interface.
     *
     * @return O JFrame da interface.
     */
    public JFrame getFrame() {
        return frame;
    }
}
