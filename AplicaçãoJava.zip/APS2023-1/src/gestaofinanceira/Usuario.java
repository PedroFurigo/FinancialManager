package gestaofinanceira;

public class Usuario {
	/**
	 * Declaração dos atributos
	 */
    private String nome;
    private double salario;
    private double saldo;

    /**
     * Método construtor
     * @param nome
     * @param salario
     */
    public Usuario(String nome, double salario) {
        this.nome = nome;
        this.salario = salario;
        this.saldo = 0.0;
    }
    /**
     * Métodos getters and setters
     */
    public void setNome(String nome) {
    	this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
    public void setSaldo(double saldo) {
    	this.saldo = saldo;
    }

    public double getSalario() {
        return salario;
    }

    public double getSaldo() {
        return saldo;
    }

    /**
     * Funções de remover ou adicionar valor ao saldo
     * @param valor
     */
    public void entradaDinheiro(double valor) {
        saldo += valor;
    }

    public void saidaDinheiro(double valor) {
        saldo -= valor;
    }
}
